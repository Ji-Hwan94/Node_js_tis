{
	"targets": [{
		"target_name": "binding",
			"sources" : ["/rint.cc"]
	}]
}