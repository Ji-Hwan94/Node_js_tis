#!/usr/bin/env node
console.log('Global Module');
console.log('argv: ', process.argv);
console.log('dirname: ', __dirname);