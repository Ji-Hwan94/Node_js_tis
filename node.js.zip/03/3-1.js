console.log('filename:', __filename);
console.log('dirname:', __dirname);