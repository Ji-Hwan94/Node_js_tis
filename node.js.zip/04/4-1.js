// moduel (require는 java에서의 import과 같은 역할)
var os = require('os');